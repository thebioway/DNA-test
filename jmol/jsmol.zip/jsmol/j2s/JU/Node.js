Clazz.declarePackage ("JU");
Clazz.load (["JU.SimpleNode"], "JU.Node", null, function () {
Clazz.declareInterface (JU, "Node", JU.SimpleNode);
});
